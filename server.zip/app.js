const express = require('express');
const server = require('./server');
const cookieParser = require('cookie-parser');
const user = require('./user/user.route')
const {requireAuth,createToken} = require('./middleware/authmiddleware')


const app = express();
//middleware
app.use(cookieParser());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

 
// routes
app.use('/api/token',createToken)
app.use('/api/user',requireAuth,user);


// database connection and app start
server.connectDb(app);
