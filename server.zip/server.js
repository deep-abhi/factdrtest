const mongoose = require('mongoose');
require('dotenv').config();

const uri = process.env.DB_URI;

function connectDb(app) {
    mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true })
        .then((connection)=>{
           console.log('MongoDb Connected')
           app.listen(3000,(data,error)=>{
              if(error){
                  console.log(error)
              }else{
                  console.log("App listed on port: 3000");
              }
           });
        }).catch((error)=>{
            console.log('MongoDb connection fail')
        });

}

module.exports = {connectDb}
