const csv = require('csvtojson');
const path = require('path');

const csvFilePath = path.resolve('./userfile/input.csv');

async function tojson(req,res,next){
    console.log(csvFilePath);
    const jsonArray = await csv({delimiter:'|'}).fromFile(csvFilePath);
    req.userdata = jsonArray;
    next();
}

module.exports = {tojson}