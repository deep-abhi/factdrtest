const jwt = require('jsonwebtoken');

const requireAuth = (req, res, next) => {
    const token = req.cookies.jwt;
    if (token) {
        jwt.verify(token, process.env.key, (err, decodedToken) => {
            if (err) {
                return res.json({ message: 'Token error' });
            } else {
                console.log(decodedToken);
                next();
            }
        });
    } else {
        return res.json({ message: 'Generate new token for api access' });
    }
};

const maxAge = 3 * 24 * 60 * 60;

const createToken = (req, res) => {
    const token = jwt.sign({ email: req.body.email }, process.env.key, { expiresIn: maxAge });
    return res.cookie('jwt', token, { httpOnly: true, maxAge: maxAge * 1000 })
        .json({ message: 'token added' });
};


module.exports = { requireAuth, createToken };