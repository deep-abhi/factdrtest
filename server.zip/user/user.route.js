const express = require('express');
const userCtrl = require('./user.controller');
const csvtojson = require('../middleware/csvtojson')
const router = express.Router();

router.post('/',userCtrl.adduser);
router.get('/',userCtrl.getuser);
router.delete('/',userCtrl.deluser);
router.put('/',userCtrl.updateuser);
router.post('/bulk',csvtojson.tojson,userCtrl.bulkuser);


module.exports = router;