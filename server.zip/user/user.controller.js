const User = require("./user.model");
const async = require('async');
const { resolve } = require("path");

const adduser = async  (req,res) =>{ 
      const user = new User();
      user.firstname = req.body.firstname;
      user.lastname =  req.body.lastname;
      user.email = req.body.email;
      user.password = req.body.password;
      user.phone = req.body.phone;
      user.gender = req.body.gender;
      user.city = req.body.city;
      user.save().then(result=>{
          return res.status(200).json({userId:result._id,email:result.email});
      }).catch(error=>{
          return res.status(500).json({error:error})
      });
}

const getuser = (req,res) => {
    User.findOne({ email: req.body.email })
    .then((result) => {
        return res.status(200).json({ data: result })
    }).catch(() => {
        return res.status(400).json({ data: "fail" })
    });
}

const deluser = (req,res) =>{
    User.findOneAndDelete({email:req.body.email})
    .then((result)=>{
        return res.status(200).json({ data: 'user deleted'})
    })
    .catch((error)=>{
        return res.status(400).json({ data: error })
    })

}

const updateuser = async (req,res) =>{
    User.findOneAndUpdate({email:req.body.email},req.body).then((result)=>{
        return res.status(200).json({ data:result})
    })
    .catch((error)=>{
        return res.status(400).json({ data: error })
    })
}

const bulkuser = (req,res) => {
    const resultdata = [];
    const faildata = [];
    async.mapLimit(req.userdata,5,(item,cb)=>{
        const {firstname,lastname,email,password,phone,gender,city} = item;
        const user = new User({firstname,lastname,email,password,phone,gender,city});
        user.save().then((result)=>{
            resultdata.push({id:result._id,email:result.email})
            cb(null);
        }).catch((error)=>{
            console.log(error);
            faildata.push({emailId:item.email})
            cb(null);
        });
    })
    // req.userdata.forEach((item)=>{
    //     const {firstname,lastname,email,password,phone,gender,city} = item;
    //     const user = new User({firstname,lastname,email,password,phone,gender,city});
    //     user.save().then((result)=>{
    //         resultdata.push({id:result._id,email:result.email})
    //     }).catch((error)=>{
    //         faildata.push({emailId:item.email})
    //     });
    // });
   return res.json({success:resultdata.length,fail:faildata.length});
}


//     User.insertMany(req.userdata).then((data)=>{
//         console.log(data);
//         return res.json({data:data})
//     }).catch((error)=>{
//         console.log(error)
//         return res.status(400).json({ data: error })
//     })
// }



module.exports = {
    adduser,
    getuser,
    deluser,
    updateuser,
    bulkuser
}


