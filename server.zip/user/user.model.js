const mongoose = require('mongoose');
const { isEmail } = require('validator');
const bcrypt = require('bcrypt');

const userSchema = new mongoose.Schema({
    firstname: {
        type: String,
        lowercase: true,
        require: [true, 'Please enter the firstname']
    },
    lastname: {
        type: String,
        lowercase: true,
        require: [true, 'Please enter the lastname']
    },
    email: {
        type: String,
        lowercase: true,
        require: [true, 'Please enter the email'],
        unique: true,
        validate: [isEmail, 'Please enter a valid email']
    },
    password: {
        type: String,
        lowercase: true,
        require: [true, 'Please enter the password']
    },
    phone: {
        type: String,
        lowercase: true,
        require: [true, 'Please enter the phone no'],
        unique: true
    },
    gender: {
        type: String,
        lowercase: true,
        require: [true, 'Please enter the Gender']
    },
    city: {
        type: String,
        lowercase: true,
        require: [true, 'Please enter the city']
    },
    status: {
        type: String,
        default: true
    }
})

userSchema.methods.toJSON = function () {
    var obj = this.toObject();
    delete obj.password;
    return obj;
}

userSchema.pre('save', async function (next) {
    const salt = await bcrypt.genSalt();
    this.password = await bcrypt.hash(this.password, salt);
    next();
});

const User = mongoose.model('user', userSchema);

module.exports = User;
